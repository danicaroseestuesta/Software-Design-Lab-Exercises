def additive_product(m, n):
    
    if n == 0: # Base case
        return 0
    elif n < 0 and m > 0:
        return -m + additive_product(m, n+1)
    elif n > 0 and m < 0:
        return m + additive_product(m, n-1)
    else:
        return abs(m) + additive_product(abs(m), abs(n)-1)

print(additive_product(5, 2))
print(additive_product(-5, 2))
print(additive_product(5, -2))
print(additive_product(-5, -2))