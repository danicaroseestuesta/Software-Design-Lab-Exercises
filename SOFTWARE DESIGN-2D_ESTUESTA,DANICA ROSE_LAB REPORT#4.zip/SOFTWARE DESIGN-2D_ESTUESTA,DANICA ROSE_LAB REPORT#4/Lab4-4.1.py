def find_max(S):
    if len(S) < 1:
        return -1
    if len(S) <= 1:
        return S[0]
    if S[0] > S[-1]:
        return find_max(S[:-1])
    else:
        return find_max(S[1:])
    
    
print(find_max([10,2,3,9,4,7,3]))
print(find_max([1,5,14,6,8,2,7,10]))