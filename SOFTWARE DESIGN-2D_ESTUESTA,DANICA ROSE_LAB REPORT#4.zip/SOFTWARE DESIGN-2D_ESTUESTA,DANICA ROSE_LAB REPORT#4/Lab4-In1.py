def maxmin(data,n):
    if n == 1:
        return data[0],data[0]
    else:
        x ,y= maxmin(data, n - 1)
        return data[n - 1] if (data[n - 1] > x) else x, data[n - 1] if (data[n - 1] <y) else y
data=[2,4,7,8,10,14,21,17,34,60]
m,n=maxmin(data,10)
print(m,n)