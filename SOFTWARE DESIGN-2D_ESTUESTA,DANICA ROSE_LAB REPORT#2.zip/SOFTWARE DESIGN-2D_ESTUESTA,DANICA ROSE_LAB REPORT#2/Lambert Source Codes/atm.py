from breezypythongui import EasyFrame
from bank import Bank, createBank
# Code for the ATM class goes here (in atm.py)
def main(fileName = None):
    """Creates the bank with the optional file name,
    wraps the window around it, and opens the window.
    Saves the bank when the window closes."""
    if not fileName:
        bank = createBank(5)
    else:
        bank = Bank(fileName)
    print(bank) # For testing only
    atm = ATM(bank)
    atm.mainloop()
# Could save the bank to a file here.
if __name__ == "__main__":
    main()
    