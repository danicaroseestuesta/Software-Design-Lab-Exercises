import random

class Doctor():

    history = []

    hedges = ("Please tell me more.",
    "Many of my patients tell me the same thing.",
    "Please continue.")

    qualifiers = ("Why do you say that?",
    "You seem to think that ",
    "Can you explain why?")

    replacements = {"I":"you","me":"you","my":"your"
    "we","you":"us","you":"mine","yours"
    "you":"I","your":"my","yours":"mine"}

    def __init__(self):
        pass

    #Greeting message
    def greeting(self):
        return "Good morning. I hope you are doing good!\nWhat can I do for you?"

    #Farewell message
    def farewell(self):
        return "Have a nice day!"

    #Reply strategies
    def reply(self, sentence):

        replyToPatientStrategy = random.randint(1, 5)
        if replyToPatientStrategy in (1, 2):
            #Just hedge
            answer = random.choice(hedges)
        elif replyToPatientStrategy == 3 and len(history) > 3:
            #Go back to an earlier topic
            answer = "Last time yu said that" + \
                changePerson(random.choice(history))
        else:
            #take the current input and structure a reply to patient
            answer = random.choice(qualifiers) + changePerson(sentence)

        history.append(sentence)
        return answer

    #Change the patient
    def changePerson(sentence):
        words = sentence.split()
        replyWords = []
        for word in words:
            replyWords.append(replacements.get(word, word))
        return " ".join(replyWords)

    #Manage interaction between patient and doctor.
    def main():
        doctor = Doctor()
        print(doctor.greeting())
        while True:
            sentence = input("\n>>")
            if sentence.upper() == "QUIT":
                print(doctor.farewell())
                break
            print(doctor.reply(sentence))

    if __name__=="__main__":
        main()