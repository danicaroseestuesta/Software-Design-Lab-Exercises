class Node:
    def __init__(self, data=None, next=None):
        self.data = data
        self.next = next

class Stack:

    def __init__(self):
        self.top = None
 
    def push(self, data):
        if self.top is None:
            self.top = Node(data, None)
            return
        self.top = Node(data, self.top)

    def pop(self):
        if self.top is None:
            return
        temp = self.top
        if self.top is not None:
            self.top = self.top.next
        temp.next = None
        return temp.data
 
    def peek(self):
        return self.top.data

    def clearstack(self):
        self.top = None

    def emptystack(self):
        if self.top is None:
            return True
        return False

    def display(self):
        itr = self.top
        sstr = ' '
        while itr:
            sstr += str(itr.data) + '-->'
            itr = itr.next
        print(sstr)

if __name__ == "__main__":
    stack = Stack()
    stack.push(1)
    stack.push(2)
    stack.push(4)
    stack.peek()
    stack.display()
    stack.pop()
    stack.push(3)
    stack.display()
    stack.clearstack()
    stack.display()