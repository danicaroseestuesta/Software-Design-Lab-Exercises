class Node:
	def __init__(self, key):
		self.left = None
		self.right = None
		self.val = key

# A function to do inorder tree traversal
def printInorder(root):
	if root:
		printInorder(root.left)
		print(root.val),
		printInorder(root.right)

# A function to do postorder tree traversal
def printPostorder(root):
	if root:
		printPostorder(root.left)
		printPostorder(root.right)
		print(root.val),

# A function to do preorder tree traversal
def printPreorder(root):
	if root:
		print(root.val),
		printPreorder(root.left)
		printPreorder(root.right)

# Function to get the left height of
# the binary tree
def left_height(node):
	ht = 0
	while(node):
		ht += 1
		node = node.left
		
	# Return the left height obtained
	return ht

# Function to get the right height
# of the binary tree
def right_height(node):
	ht = 0
	while(node):
		ht += 1
		node = node.right
		
	# Return the right height obtained
	return ht

# Function to get the count of nodes
# in complete binary tree
def TotalNodes(root):

	if(root == None):
		return 0
	
	lh = left_height(root)
	rh = right_height(root)
	
	if(lh == rh):
		return (1 << lh) - 1
	
	return 1 + TotalNodes(root.left) + TotalNodes(root.right)


root = Node(1)
root.left = Node(2)
root.right = Node(3)
root.left.left = Node(4)
root.left.right = Node(5)

print ("Preorder traversal of binary tree:")
printPreorder(root)
print ("\nInorder traversal of binary tree:")
printInorder(root)
print ("\nPostorder traversal of binary tree:")
printPostorder(root)
print("Number of nodes in the binary tree:")
print(TotalNodes(root))